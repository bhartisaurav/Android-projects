package com.example.saurav.currencyconvertor;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    public void Convert(View view)
    {
        EditText ed=findViewById(R.id.EditText1);
        String val= ed.getText().toString();
        double data=Double.parseDouble(val);
        double result=data*73.40;
        String res= "₹ "+result;
        Toast.makeText(MainActivity.this,res,Toast.LENGTH_LONG).show();

    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}

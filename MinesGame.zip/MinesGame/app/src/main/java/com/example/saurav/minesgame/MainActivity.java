package com.example.saurav.minesgame;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;

import android.graphics.drawable.PaintDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Handler;
import android.os.SystemClock;
import android.provider.Settings;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.TextView;
import android.widget.Toast;

import com.pedromassango.doubleclick.DoubleClick;
import com.pedromassango.doubleclick.DoubleClickListener;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;


public class MainActivity extends AppCompatActivity {
    public static final String PREFS_NAME = "MyPrefsFile";

String time="00:00";
Button bt;
int i=0;//click count
 int count=0;
TextView textView=null;
int[] visited=new int[80];       // It store both visited and non-visited block.
int Dclick_count=0;
int[] flag=new int[80];
private Chronometer chronometer=null;
private boolean running;

Drawable d1=null,d2,d3;
long elapsedMillis ;
int[] bomb=new int[100];
int limit=54;
int[] U_random=new int[80];
ArrayList<Button> buttons=new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView=findViewById(R.id.tv5);
        SharedPreferences settings = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);



        String score = settings.getString("HighScore", "");
        textView.setText(score);
        bt = null;
        textView = findViewById(R.id.tv1);
        chronometer = findViewById(R.id.meter);

        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                String num_id = "button_" + String.valueOf(i) + j;
                int id = getResources().getIdentifier(num_id, "id", getPackageName());

                buttons.add((Button) findViewById(id));
            }
        }
         bt=findViewById(R.id.button_00);
         d3=bt.getBackground();



             for (int i = 0; i < 64; i++) {
                 buttons.get(i).setOnClickListener(new DoubleClick(new DoubleClickListener() {
                     @Override
                     public void onSingleClick(View view) {
                         d2 = view.getBackground();
                         System.out.println("enter1");
                         String id1 = getResources().getResourceEntryName(view.getId());
                         bt = view.findViewById(getResources().getIdentifier(id1, "id", getPackageName()));
                         // d1 = view.getBackground();

                         int n = 10;
                         int n1 = 0, n2 = 0;
                         if (count == 0) {
                             System.out.println("bombs:");
                             while (n > 0) {
                                 startTimer();
                                 n1 = getRandomNumber();
                                 n2 = getRandomNumber();
                                 while(U_random[n1*10+n2]==1)
                                 {
                                     n1 = getRandomNumber();
                                     n2 = getRandomNumber();
                                 }
                                 U_random[n1*10+n2]=1;
                                 String num_id = String.valueOf(n1) + String.valueOf(n2);
                                 num_id = "button_" + num_id;
                                 if (checkNeighbour(id1, n1, n2)) {
                                     bt = findViewById(getResources().getIdentifier(num_id, "id", getPackageName()));  //how to set content of a string in findviewbyid.
                                     //bt.setBackgroundColor(Color.WHITE);
                                     bomb[n1 * 10 + n2] = 1;
                                     System.out.print((n1 * 10 + n2) + " ");
                                     //bt.setBackgroundResource(R.drawable.bomb);
                                     n = n - 1;
                                 }

                             }

                             String[] str = id1.split(""); // to store name of button(like button_01) in string array split by ""(no white space).
                             int a = Integer.parseInt(str[8]);
                             int b = Integer.parseInt(str[9]);
                             System.out.println("a:" + a + "b:" + b);
                             if (bomb[a * 10 + b] != 1)
                                 findEmptySpot(a, b);
                             else {
                                 bt.setBackgroundColor(Color.WHITE);
                                 bt.setBackgroundResource(R.drawable.bomb);
                                 isHalt(1);

                             }


                         } else {

                             String[] str = id1.split("");
                             int a = Integer.parseInt(str[8]);
                             int b = Integer.parseInt(str[9]);
                             if (bomb[a * 10 + b] != 1)
                                 findEmptySpot(a, b);
                             else {
                                 bt.setBackgroundColor(Color.WHITE);
                                 bt.setBackgroundResource(R.drawable.bomb);
                                 isHalt(1);
                             }


                         }
                         count = count + 1;
                     }


                     @Override
                     public void onDoubleClick(View view) {
                         if (count > 0) {
                             System.out.println("enter2");
                             String id1 = getResources().getResourceEntryName(view.getId());
                             bt = view.findViewById(getResources().getIdentifier(id1, "id", getPackageName()));
                             d1 = view.getBackground();
                             if (d1.getConstantState() != getResources().getDrawable(R.drawable.ic_flag).getConstantState() && bt.getText() == ""&&Dclick_count<10) {
                                 bt.setBackgroundResource(R.drawable.ic_flag);
                                 Dclick_count++;
                                 textView.setText(String.valueOf(Dclick_count));
                             } else
                                 if(bt.getText()==""&&d1.getConstantState() == getResources().getDrawable(R.drawable.ic_flag).getConstantState()){
                                 bt.setBackground(d2);
                                 Dclick_count--;
                                 textView.setText(String.valueOf(Dclick_count));
                             }

                         }
                     }
                 }, 250));

                 findViewById(R.id.restart).setOnClickListener(new View.OnClickListener() {
                     @Override
                     public void onClick(View v) {
                         restartActivity();
                     }
                 });


             }


    }

    @Override
    protected void onStop() {
        super.onStop();
        SharedPreferences settings = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        SharedPreferences.Editor editor = settings.edit();
        editor.putString("HighScore",time);

        // Commit the edits!
        editor.apply();
    }

    public void startTimer()
    {
        if(!running) {



            chronometer.setBase(SystemClock.elapsedRealtime()-1000);
            chronometer.start();

        }
        else {
             elapsedMillis = SystemClock.elapsedRealtime() - chronometer.getBase();
            running = true;
        }

    }
    public void restartActivity()
    {
        Intent intent= new Intent(this, MainActivity.class);
        startActivity(intent);
    }


    public int getRandomNumber() {
        /* generate random number to find the place of bombs */
        Random random = new Random();
        return (random.nextInt(8));
    }

    public boolean checkNeighbour(String s1,int n3,int n4 )
    {  /* to check whether bomb is in neighbourhood of button clicked box. */
       String[] str=s1.split("");

        int n1=Integer.parseInt(str[8]);
        int n2=Integer.parseInt(str[9]);

        if(((n1==n3)&(n2==n4))||((n1==n3)&&(n2+1==n4))||((n1==n3)&&(n2-1==n4))||((n1-1==n3)&&(n2==n4))||((n1+1==n3)&&(n2==n4)))
            return false;
        if(((n1+1==n3)&&(n2+1==n4))||((n1+1==n3)&&(n2-1==n4))||((n1-1==n3)&&(n2+1==n4))||((n1-1==n3)&&(n2-1==n4)))
            return false;
          return true;

    }
    public String getButtonId(int i ,int j)
    {
        /* generate name of button(also called ID) using value of i and j */
        String num_id = String.valueOf(i) + String.valueOf(j);
        num_id = "button_" + num_id;
        return num_id;
    }
    public int findNumBomb(int i,int j)
    {
        /* return number of bombs in neighbour*/
        int count=0;
       // System.out.println("i:"+i+" j:"+j);
        if(i>=0&&j+1>=0&&i<8&&j+1<8)
        {
           String num_id=getButtonId(i,j+1);
            bt = findViewById(getResources().getIdentifier(num_id, "id", getPackageName()));   // find the button id using name of a button.
            Drawable d1=bt.getBackground();
            if(bomb[i*10+(j+1)]==1)//d1.getConstantState()==getResources().getDrawable(R.drawable.bomb).getConstantState())  // to check whether the exiting block has bomb or not.
             count++;
        }
        if(i>=0&&j-1>=0&&i<8&&j-1<8)
        {
            String num_id=getButtonId(i,j-1);
            bt = findViewById(getResources().getIdentifier(num_id, "id", getPackageName()));
            Drawable d1=bt.getBackground();
            if(bomb[i*10+(j-1)]==1)//d1.getConstantState()==getResources().getDrawable(R.drawable.bomb).getConstantState())
            count++;


        }
        if(i+1>=0&&j>=0&&i+1<8&&j<8)
        {
            String num_id=getButtonId(i+1,j);
            bt = findViewById(getResources().getIdentifier(num_id, "id", getPackageName()));
            Drawable d1=bt.getBackground();
            if(bomb[(i+1)*10+(j)]==1)//d1.getConstantState()==getResources().getDrawable(R.drawable.bomb).getConstantState())
            count++;

        }
        if(i-1>=0&&j>=0&&i-1<8&&j<8)
        {
            String num_id=getButtonId(i-1,j);
            bt = findViewById(getResources().getIdentifier(num_id, "id", getPackageName()));
            Drawable d1=bt.getBackground();
            if(bomb[(i-1)*10+(j)]==1)//d1.getConstantState()==getResources().getDrawable(R.drawable.bomb).getConstantState())
            count++;

        }
        if(i+1>=0&&j+1>=0&&i+1<8&&j+1<8)
        {
            String num_id=getButtonId(i+1,j+1);
            bt = findViewById(getResources().getIdentifier(num_id, "id", getPackageName()));
            Drawable d1=bt.getBackground();
            if(bomb[(i+1)*10+(j+1)]==1)//d1.getConstantState()==getResources().getDrawable(R.drawable.bomb).getConstantState())
            count++;

        }
        if(i+1>=0&&j-1>=0&&i+1<8&&j-1<8)
        {
            String num_id=getButtonId(i+1,j-1);
           // System.out.println("num_id"+num_id);
            bt = findViewById(getResources().getIdentifier(num_id, "id", getPackageName()));
            Drawable d1=bt.getBackground();
            if(bomb[(i+1)*10+(j-1)]==1)//d1.getConstantState()==getResources().getDrawable(R.drawable.bomb).getConstantState())
             count++;

        }
        if(i-1>=0&&j+1>=0&&i-1<8&&j+1<8)
        {
            String num_id=getButtonId(i-1,j+1);
            bt = findViewById(getResources().getIdentifier(num_id, "id", getPackageName()));
            Drawable d1=bt.getBackground();
            if(bomb[(i-1)*10+(j+1)]==1)//d1.getConstantState()==getResources().getDrawable(R.drawable.bomb).getConstantState())
            count++;

        }
        if(i-1>=0&&j-1>=0&&i-1<8&&j-1<8)
        {
            String num_id=getButtonId(i-1,j-1);
            bt = findViewById(getResources().getIdentifier(num_id, "id", getPackageName()));
            Drawable d1=bt.getBackground();
            if(bomb[(i-1)*10+(j-1)]==1)//d1.getConstantState()==getResources().getDrawable(R.drawable.bomb).getConstantState())
            count++;

        }
        return count;

    }

    public void pushAllNeighbour(Queue<Integer> q,int i,int j)
    {
        /* find all the neighbours of a given block and push all neighbour in a queue if the neighbour not visited. */
        if(i>=0&&j+1>=0&&i<8&&j+1<8)
        { int n =i*10+(j+1); if(visited[n]!=1) q.add(n); }

        if(i>=0&&j-1>=0&&i<8&&j-1<8)
        { int n =i*10+(j-1); if(visited[n]!=1) q.add(n); }

        if(i+1>=0&&j>=0&&i+1<8&&j<8)
        { int n =(i+1)*10+j; if(visited[n]!=1) q.add(n); }

        if(i-1>=0&&j>=0&&i-1<8&&j<8)
        { int n =(i-1)*10+j; if(visited[n]!=1); q.add(n); }

        if(i+1>=0&&j+1>=0&&i+1<8&&j+1<8)
        { int n =(i+1)*10+(j+1); if(visited[n]!=1)  q.add(n); }

        if(i+1>=0&&j-1>=0&&i+1<8&&j-1<8)
        { int n =(i+1)*10+(j-1); if(visited[n]!=1) q.add(n); }

        if(i-1>=0&&j+1>=0&&i-1<8&&j+1<8)
        { int n =(i-1)*10+(j+1); if(visited[n]!=1) q.add(n); }

        if(i-1>=0&&j-1>=0&&i-1<8&&j-1<8)
        { int n =(i-1)*10+(j-1); if(visited[n]!=1); q.add(n); }

    }
    public void findEmptySpot(int i,int j)
    {/* to check near empty spots, where there is no bombs in their neighbourhood.*/
        int k=0;
        Queue<Integer> q = new LinkedList<>();
        int n=i*10+j;
        q.add(n);                 // add(): function use the push the element in queue.
        while(!q.isEmpty())
        {
            int head=q.peek();    // peek(): function use to get the front of a queue.
            j=head%10;
            i=head/10;

                k = findNumBomb(i, j);
                if (k > 0&&visited[i*10+j]!=1) {
                    visited[i*10+j]=1;                        // set 1 for visited block, set 0 for non-visited block.
                    String num_id = getButtonId(i, j);
                    bt = findViewById(getResources().getIdentifier(num_id, "id", getPackageName()));
                    bt.setText(String.valueOf(k));

                    limit--;


                    System.out.println("id: "+i+""+j);
                    System.out.println("limit:"+limit);

                    q.remove();    // remove(): function use to pop() the element from the top of queue.
                    if(limit<=0)
                        isHalt(0);
                }
                else
                 if(k<=0&&visited[i*10+j]!=1)
                {
                    visited[head]=1;
                    String num_id=getButtonId(i,j);
                    bt = findViewById(getResources().getIdentifier(num_id, "id", getPackageName()));
                    //bt.setText("*");
                    bt.setBackgroundColor(getResources().getColor(R.color.opaque));
                    bt.setEnabled(false);
                    limit--;
                    System.out.println("id: "+i+""+j);
                    System.out.println("limit:"+limit);
                    pushAllNeighbour(q, i, j);

                    q.remove();
                    if(limit<=0)
                        isHalt(0);

                }
                else
                    if(visited[i*10+j]==1)
                        q.remove();

            }


    }
    public String compareScore(String s1,String s2)
    {
        System.out.println("time:"+s1);
        String[] str1 = s1.split("");
        System.out.println("time1:"+str1[1]);
        int m11=Integer.parseInt(str1[1]);
        int m12=Integer.parseInt(str1[2]);
        int sec11=Integer.parseInt(str1[4]);
        int sec12=Integer.parseInt(str1[5]);

        String[] str2 = s2.split("");
        int m21=Integer.parseInt(str2[1]),m22=Integer.parseInt(str2[2]),sec21=Integer.parseInt(str2[4]),sec22=Integer.parseInt(str2[5]);

        if((((m11*10)+m12)+0.1*(sec11+sec12))<=(((m21*10)+m22)+0.1*(sec21+sec22)))
        return s1;
        else
            return s2;
    }

    public void isHalt(int flag)
    {

         for(int i=0;i<64;i++)
         {
             int a = i/8;
             int b = i%8;
             System.out.println("enter isHalt");
             Button btn= buttons.get(i);
             btn.setEnabled(false);


                 if(bomb[a*10+b]==1)
                 {

                     buttons.get(i).setBackgroundResource(R.drawable.bomb);
                 }
                 //else
                   //  buttons.get(i).setBackgroundColor(getResources().getColor(R.color.light_black));

             }
             if(flag==1)
        Toast.makeText(getApplicationContext(),"Game Over!!",Toast.LENGTH_LONG).show();
         else
             {Toast.makeText(getApplicationContext(),"You Win!!",Toast.LENGTH_LONG).show();  }
       // String formatType=chronometer.getFormat();


        String time2=(String)chronometer.getText();       //current score


        System.out.println("Lasttime:"+time);
         chronometer.stop();
         if(flag==0) {
             textView=findViewById(R.id.tv5);
             String time1=(String)textView.getText(); //previous score
             if(!time1.equals("00:00"))
             time = compareScore(time1, time2);
             else
             time=time2;
         }
        onStop();

         }
    }



